document.getElementById("demo").onmouseover = function() {mouseOver()};
document.getElementById("demo").onmouseout = function() {mouseOut()};

function mouseOver() {
  document.getElementById("demo").src="chest.png";
}

function mouseOut() {
  document.getElementById("demo").src="chest.png";
}